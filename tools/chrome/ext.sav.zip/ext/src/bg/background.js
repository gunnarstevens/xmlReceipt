// if you checked "fancy-settings" in extensionizr.com, uncomment this lines
// var settings = new Store("settings", {
//      "sample_setting": "This is how you use Store.js to remember values"
// });

var jsonReceipt = null;

debugger;
const RECEIPTS_PATH = "/anonymous/receipts";

var config = {
    apiKey: "AIzaSyD5plOi9OhTJnLF-3sfbqLtcn94xcIcXa4",
    authDomain: "consumerview.firebaseapp.com",
    databaseURL: "https://consumerview.firebaseio.com",
    storageBucket: "firebase-consumerview.appspot.com",
};

//firebase.initializeApp(config);
//var receipts = firebase.database.list(RECEIPTS_PATH);
//var key = receipts.push().set("TEST");


chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        debugger;
        chrome.browserAction.setIcon({path: '../../icons/logo32.png'});
        jsonReceipt = request;
        console.log(sender.tab ?
        "from a content script:" + sender.tab.url :
            "from the extension");
    });
