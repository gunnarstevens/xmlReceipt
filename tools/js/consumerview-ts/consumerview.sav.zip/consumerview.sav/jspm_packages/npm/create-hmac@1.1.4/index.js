/* */ 
module.exports = require('crypto').createHmac;
