/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('vm') : require('vm-browserify');