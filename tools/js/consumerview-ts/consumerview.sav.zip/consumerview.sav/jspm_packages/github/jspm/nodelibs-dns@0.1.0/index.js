/* */ 
if (System._nodeRequire)
  module.exports = System._nodeRequire('dns');
else
  throw "Node dns module not supported in browsers.";