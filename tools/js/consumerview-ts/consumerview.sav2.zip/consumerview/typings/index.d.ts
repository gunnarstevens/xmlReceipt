/// <reference path="globals/firebase3/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/x2js/xml2json.d.ts" />
/// <reference path="modules/es6-promise/index.d.ts" />
