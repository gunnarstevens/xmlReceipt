// Typings reference file, see links for more information
// https://github.com/typings/typings
// https://www.typescriptlang.org/docs/handbook/writing-declaration-files.html
//-- everything is defined in main <reference path="../typings/browser.d.ts" />
/// <reference path="../typings/main.d.ts" />

declare var module: { id: string };
