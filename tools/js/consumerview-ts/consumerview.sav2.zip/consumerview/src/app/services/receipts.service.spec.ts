/* tslint:disable:no-unused-variable */

/* TODO: Inject html request
import { RECEIPTS } from '../mocks/receipts.mock';

import {
  beforeEach, beforeEachProviders,
  describe, xdescribe,
  expect, it, xit,
  async, inject
} from '@angular/core/testing';
  import { ReceiptsService } from './receipts.service';
describe('Receipts Service', () => {
  beforeEachProviders(() => [ReceiptsService]);

  it('should create the service',
      inject([ReceiptsService], (service: ReceiptsService) => {
    expect(service).toBeTruthy();
  }));

  it('should have as title \'app works!\'',
    inject([ReceiptsService], (service: ReceiptsService) => {
      expect(service.getReceipts()).toEqual(RECEIPTS);
    }));
});
*/
