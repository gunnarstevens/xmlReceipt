/* tslint:disable:no-unused-variable */

/*
import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { RECEIPTS } from '../../mocks/receipts.mock';
import {ReceiptsService} from '../../services/receipts.service'
import { ReceiptsOutlineViewComponent } from './receiptsoutlineview.component';

import {
  beforeEach, beforeEachProviders,
  describe, xdescribe,
  expect, it, xit,
  async, inject
} from '@angular/core/testing';

describe('Component: Receiptslist', () => {
  it('should create an instance', () => {
    let component = new ReceiptsOutlineViewComponent(new ReceiptsService());
    expect(component).toBeTruthy();
  });

  it('should create an instance', () => {
    let component = new ReceiptsOutlineViewComponent(new ReceiptsService());
    component.ngOnInit();
    expect(component.getReceipts()).toEqual(RECEIPTS);
  });
});
*/
