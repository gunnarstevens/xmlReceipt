export * from './receiptsoutlineview.component';
