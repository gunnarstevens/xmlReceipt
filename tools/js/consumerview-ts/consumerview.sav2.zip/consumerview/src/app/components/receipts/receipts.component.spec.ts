/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { RECEIPTS } from '../../mocks/receipts.mock';
import {ReceiptsService} from '../../services/receipts.service'
import { ReceiptsComponent } from './receipts.component';


import {
  beforeEach, beforeEachProviders,
  describe, xdescribe,
  expect, it, xit,
  async, inject
} from '@angular/core/testing';

/*
describe('Component: Receipts', () => {
  it('should create an instance', () => {
    let component = new ReceiptsComponent(new ReceiptsService());
    expect(component).toBeTruthy();
  });

  it('should create an instance', () => {
    let component = new ReceiptsComponent(new ReceiptsService());
    component.ngOnInit();
    expect(component.getReceipts()).toEqual(RECEIPTS);
  });
});
*/
